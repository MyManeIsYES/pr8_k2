package com.bignerdranch.android.pr8_k

import android.content.Intent
import android.content.SharedPreferences
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.EditText
import android.widget.Toast

class Login : AppCompatActivity() {
    lateinit var email:EditText
    lateinit var password:EditText
    lateinit var pref:SharedPreferences
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        email=findViewById(R.id.email)
        password=findViewById(R.id.password)
        pref=getPreferences(MODE_PRIVATE)
    }
    fun SignIn(view: View){
        if(email.text.toString().isNotEmpty() && password.text.toString().isNotEmpty()){
            if(email.text.toString() == pref.getString("email","")){
                if(password.text.toString() == pref.getString("password","")){
                    val intent= Intent(this,Menu::class.java)
                    startActivity(intent)
                }
                else{
                    Toast.makeText(this, "неправильный пароль", Toast.LENGTH_SHORT).show()
                }
            }
            else{
                val alert = AlertDialog.Builder(this)
                    .setTitle("ошибка")
                    .setMessage("Нет такого пользователя (Зарегистрируйтесь)")
                    .setPositiveButton("OK",null)
                    .create()
                    .show()
            }
        }
        else{
            val alert = AlertDialog.Builder(this)
                .setTitle("ошибка")
                .setMessage("У вас есть незаполненые поля")
                .setPositiveButton("OK",null)
                .create()
                .show()
        }
    }
    fun Registr(view: View){
        if(email.text.toString().isNotEmpty() && password.text.toString().isNotEmpty()){
            var prefEditor=pref.edit()
            prefEditor.putString("email",email.text.toString())
            prefEditor.putString("password",password.text.toString())
            prefEditor.apply()
            Toast.makeText(this, "Регистрация прошла успешно", Toast.LENGTH_SHORT).show()
        }
        else{
            val alert = AlertDialog.Builder(this)
                .setTitle("ошибка")
                .setMessage("У вас есть незаполненые поля")
                .setPositiveButton("OK",null)
                .create()
                .show()

        }
    }
}