package com.bignerdranch.android.pr8_k

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.widget.Toast

class Menu : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_menu)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu2, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.profile -> {
                var intent = Intent(this, Profile::class.java)
                startActivity(intent)
                Toast.makeText(this, "Выбран Профиль",Toast.LENGTH_SHORT).show()
                true
            }
            R.id.weather -> {
                var intent = Intent(this, Wearthers::class.java)
                startActivity(intent)
                Toast.makeText(this, "Выбран Погода",Toast.LENGTH_SHORT).show()
                true
            }
            else->super.onOptionsItemSelected(item)
        }
    }
}